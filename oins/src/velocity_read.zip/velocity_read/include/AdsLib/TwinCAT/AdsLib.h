// SPDX-License-Identifier: MIT
/**
   Copyright (c) 2020 - 2022 Beckhoff Automation GmbH & Co. KG
 */
#pragma once

#include "AdsDef.h"
#include <TcAdsAPI.h>
