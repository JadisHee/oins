#include "../include/AdsLib/AdsLib.h"
#include "../include/AdsLib/AdsNotificationOOI.h"
#include "../include/AdsLib/AdsVariable.h"

#include <array>
#include <iomanip>
#include <queue>
#include <cmath>
#include <ctime>
#include <fstream>
#include <thread>
#include <atomic>
#include <array>
#include <cstdint>
#include <string.h>
#include <algorithm>

int main()
{
    static const AmsNetId remoteNetId { 169, 254, 27, 166, 1, 1 };
    static const char remoteIpV4[] = "169.254.27.166";
    AdsDevice route {remoteIpV4, remoteNetId, AMSPORT_R0_PLC_RTS1};

    
}