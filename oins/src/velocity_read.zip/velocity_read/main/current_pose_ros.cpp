#include "tf2_ros/transform_listener.h"
#include "tf2_ros/buffer.h"
#include "geometry_msgs/PointStamped.h"
#include "../include/AdsLib/AdsLib.h"
#include "../include/AdsLib/AdsNotificationOOI.h"
#include "../include/AdsLib/AdsVariable.h"
#include "../include/json.hpp"

#include <array>
#include <iomanip>
#include <queue>
#include <cmath>
#include <ctime>
#include <fstream>
#include <thread>
#include <atomic>
#include <array>
#include <cstdint>
#include <string.h>
#include <algorithm>

// 数据定义

typedef enum
{
    site_1,
    site_2
} State;
State state_temp_;
int16_t path_id;

std::vector<clock_t> time_now_;
pose_int end_point_;
bool isPublishPath;
std::vector<pose_send_vector> global_path;

void delay_msec(int msec)
{
  clock_t now = clock();
  while (clock()-now < msec);

}

void queueClear(std::queue<int16_t>& q){
  std::queue<int16_t> empty;
  std::swap(empty, q);
}

double distance(const pose_send_vector& point1, const pose_send_vector& point2)
{
  double dx = point1.pose_x - point2.pose_x;
  double dy = point1.pose_y - point2.pose_y;
  return sqrt(dx*dx + dy*dy);
}

double distance_to_line(const float& x, const float& y, const pose_send_vector& line_start, const pose_send_vector& line_end)
{
  double dx = line_end.pose_x - line_start.pose_x;
  double dy = line_end.pose_y - line_start.pose_y;
  double numerator = fabs(dy*x - dx*y + line_end.pose_x*line_start.pose_y - line_end.pose_y*line_start.pose_x);
  double denominator = distance(line_start, line_end);
  return numerator/denominator;
}

bool isAwayFromPath(const float& x, const float& y, const std::vector<pose_send_vector>& path)
{
  // 如果路径点小于两个 定位准确
  if (path.size() < 3)
  {
    return false;
  }
  std::vector<double> distance_array;
  for (size_t i = 0; i < path.size()-2; i++)
  {
    pose_send_vector line_start = path[i];
    pose_send_vector line_end = path[i+1];
    double d = distance_to_line(x*1000, y*1000, line_start, line_end);
    distance_array.push_back(d);

  }
  if(distance_array.size() != 0)
  {
    std::sort(distance_array.begin(), distance_array.end());
    // 垂直距离不能超过50cm
    std::cout << "点到直线的距离: "<<distance_array.at(0)<<std::endl;
    if (distance_array.at(0) > 500)
    {
      return true;
    } 
  }
  return false;
}

// 计算前后位置的偏差
void calculatePositionDifference(
  std::vector<std::vector<float>>& pose_vector, 
  double& pose_delta_temp)
{
  double dx = (pose_vector.end()-1)->at(0) - (pose_vector.end()-2)->at(0);
  double dy = (pose_vector.end()-1)->at(1) - (pose_vector.end()-2)->at(1);
  pose_delta_temp = hypot(dx, dy);
}

// 判断位置是否丢失
bool isPositionLoss(
  float& pose_x_current, 
  float& pose_y_current, 
  float& yaw_current,
  std::vector<std::vector<float>>& pose_xy_yaw){
  /*
  输入实时位置，输出停车信号
  */
  // 位姿队列为空，不停车
  if (pose_xy_yaw.size() < 3)
  {
    std::vector<float> pose_temp1;
    pose_temp1.push_back(pose_x_current);
    pose_temp1.push_back(pose_y_current);
    pose_temp1.push_back(yaw_current);
    pose_xy_yaw.push_back(pose_temp1);
    return false;
  }
  // 如果队列个数大于3 删除最前面一个
  if (pose_xy_yaw.size() > 3)
  {
    std::vector<std::vector<float>>::iterator k = pose_xy_yaw.begin();
    pose_xy_yaw.erase(k);

    if (pose_xy_yaw.size() != 3)
    {
      std::cout<< " +++++++++++++ size error +++++++++++++++"<<std::endl;
    }
  }
  // std::cout << "pose_xy_yaw:"<< pose_xy_yaw.size() << std::endl;
  std::vector<float> pose_temp;
  pose_temp.push_back(pose_x_current);
  pose_temp.push_back(pose_y_current);
  pose_temp.push_back(yaw_current);
  pose_xy_yaw.push_back(pose_temp);
  double pose_delta;
  calculatePositionDifference(pose_xy_yaw, pose_delta);
  // 当前后位置距离大于40cm就认为位置定位有偏差
  if (pose_delta > 0.4)
  {
    return true;
  }
  return false;
}

// xin 固定四条路径点
void fixedPathPoint(int16_t path_id,std::vector<pose_send_vector>& temp)
{
  pose_send_vector p1,p2,p3,p4,p5,p6;
  if (path_id == 1)
  {
    // 第一个拐点
    p1.pose_x = 0;
    p1.pose_y = 0;
    p1.obstacle_avoidance_signal = 0;
    p1.previous_task = 0;
    p1.post_task = 0;
    p1.mode_type = 30;
    // 第二个拐点
    p2.pose_x = 0;
    p2.pose_y = 6400;
    p2.obstacle_avoidance_signal = 0;
    p2.previous_task = 0;
    p2.post_task = 0;
    p2.mode_type = 0;
    // 虚拟终点
    temp.push_back({0,0,0,0,0,0});
    temp.insert(temp.begin(), p1);
    temp.insert(temp.begin()+1, p2);

  }

  if (path_id == 2)
  {
    // 第一个拐点
    p1.pose_x = -9.13;
    p1.pose_y = -0.85;
    p1.obstacle_avoidance_signal = 0;
    p1.previous_task = 0;
    p1.post_task = 0;
    p1.mode_type = -30;
    // 第二个拐点
    p2.pose_x = -22.5;
    p2.pose_y = -1793.8;
    p2.obstacle_avoidance_signal = 0;
    p2.previous_task = 0;
    p2.post_task = 0;
    p2.mode_type = 1;
    // 第三个拐点
    p3.pose_x = 10077;
    p3.pose_y = -1878;
    p3.obstacle_avoidance_signal = 0;
    p3.previous_task = 0;
    p3.post_task = 0;
    p3.mode_type = -1;
    // 4点
    p4.pose_x = 10216;
    p4.pose_y = 3815;
    p4.obstacle_avoidance_signal = 0;
    p4.previous_task = 0;
    p4.post_task = 0;
    p4.mode_type = -1;
    // 终点
    p5.pose_x = 10329;
    p5.pose_y = 8846;
    p5.obstacle_avoidance_signal = 0;
    p5.previous_task = 180;
    p5.post_task = 0;
    p5.mode_type = 0;
    // 虚拟终点
    temp.push_back({0,0,0,0,0,0});
    temp.insert(temp.begin(), p1);
    temp.insert(temp.begin()+1, p2);
    temp.insert(temp.begin()+2, p3);
    temp.insert(temp.begin()+3, p4);
    temp.insert(temp.begin()+4, p5);
  }
  if (path_id == 3)
  {
    // 第一个拐点
    p1.pose_x = 10329;
    p1.pose_y = 8846;
    p1.obstacle_avoidance_signal = 0;
    p1.previous_task = 0;
    p1.post_task = 0;
    p1.mode_type = 1;
    // 第二个拐点
    p2.pose_x = 10216;
    p2.pose_y = 3815;
    p2.obstacle_avoidance_signal = 0;
    p2.previous_task = 0;
    p2.post_task = 0;
    p2.mode_type = 1;
    // 第三个拐点
    p3.pose_x = 10077;
    p3.pose_y = -1878;
    p3.obstacle_avoidance_signal = 0;
    p3.previous_task = 0;
    p3.post_task = 0;
    p3.mode_type = -1;
    // 4点
    p4.pose_x = -22.5;
    p4.pose_y = -1793.8;
    p4.obstacle_avoidance_signal = 0;
    p4.previous_task = 0;
    p4.post_task = 0;
    p4.mode_type = 30;
    // 终点
    p5.pose_x = -9.13;
    p5.pose_y = -0.85;
    p5.obstacle_avoidance_signal = 0;
    p5.previous_task = 60;
    p5.post_task = 0;
    p5.mode_type = 0;
    // 虚拟终点
    temp.push_back({0,0,0,0,0,0});
    temp.insert(temp.begin(), p1);
    temp.insert(temp.begin()+1, p2);
    temp.insert(temp.begin()+2, p3);
    temp.insert(temp.begin()+3, p4);
    temp.insert(temp.begin()+4, p5);
  }
  if (path_id == 4)
  {
    // 第一个拐点
    p1.pose_x = -9.13;
    p1.pose_y = -0.85;
    p1.obstacle_avoidance_signal = 0;
    p1.previous_task = 0;
    p1.post_task = 0;
    p1.mode_type = 1;
    // 第二个拐点
    p2.pose_x = 5175;
    p2.pose_y = 22;
    p2.obstacle_avoidance_signal = 0;
    p2.previous_task = 60;
    p2.post_task = 0;
    p2.mode_type = 0;
    // 虚拟终点
    temp.push_back({0,0,0,0,0,0});
    temp.insert(temp.begin(), p1);
    temp.insert(temp.begin()+1, p2);
  }
  if (path_id == 5)
  {
    // 第一个拐点
    p1.pose_x = 5175;
    p1.pose_y = 22;
    p1.obstacle_avoidance_signal = 0;
    p1.previous_task = 0;
    p1.post_task = 0;
    p1.mode_type = -30;
    // 第二个拐点
    p2.pose_x = 5188;
    p2.pose_y = -1616;
    p2.obstacle_avoidance_signal = 0;
    p2.previous_task = 0;
    p2.post_task = 0;
    p2.mode_type = 1;
    // 第三个拐点
    p3.pose_x = 19608;
    p3.pose_y = -1795;
    p3.obstacle_avoidance_signal = 0;
    p3.previous_task = 0;
    p3.post_task = 0;
    p3.mode_type = -1;
    // 第四个拐点
    p4.pose_x = 19694;
    p4.pose_y = -9375;
    p4.obstacle_avoidance_signal = 0;
    p4.previous_task = 0;
    p4.post_task = 0;
    p4.mode_type = 30;
    // 第四个拐点
    p5.pose_x = 16782;
    p5.pose_y = -9473;
    p5.obstacle_avoidance_signal = 0;
    p5.previous_task = 60;
    p5.post_task = 0;
    p5.mode_type = 0;
    // 虚拟终点
    temp.push_back({0,0,0,0,0,0});
    temp.insert(temp.begin(), p1);
    temp.insert(temp.begin()+1, p2);
    temp.insert(temp.begin()+2, p3);
    temp.insert(temp.begin()+3, p4);
    temp.insert(temp.begin()+4, p5);
  }
  if (path_id == 6)
  {
    // 第一个拐点
    p1.pose_x = 16782;
    p1.pose_y = -9473;
    p1.obstacle_avoidance_signal = 0;
    p1.previous_task = 0;
    p1.post_task = 0;
    p1.mode_type = -30;
    // 第二个拐点
    p2.pose_x = 19694;
    p2.pose_y = -9375;
    p2.obstacle_avoidance_signal = 0;
    p2.previous_task = 0;
    p2.post_task = 0;
    p2.mode_type = 1;
    // 第三个拐点
    p3.pose_x = 19608;
    p3.pose_y = -1795;
    p3.obstacle_avoidance_signal = 0;
    p3.previous_task = 0;
    p3.post_task = 0;
    p3.mode_type = 1;
    // 第四个拐点
    p4.pose_x = -22.5;
    p4.pose_y = -1793.8;
    p4.obstacle_avoidance_signal = 0;
    p4.previous_task = 0;
    p4.post_task = 0;
    p4.mode_type = -30;
    // 第四个拐点
    p5.pose_x = -9.13;
    p5.pose_y = -0.85;
    p5.obstacle_avoidance_signal = 0;
    p5.previous_task = 60;
    p5.post_task = 0;
    p5.mode_type = 0;
    // 虚拟终点
    temp.push_back({0,0,0,0,0,0});
    temp.insert(temp.begin(), p1);
    temp.insert(temp.begin()+1, p2);
    temp.insert(temp.begin()+2, p3);
    temp.insert(temp.begin()+3, p4);
    temp.insert(temp.begin()+4, p5);
  }
}

// 从json文件中读取路径数据发送个plc
void read_path(int id, std::vector<pose_send_vector>& temp)
{
  std::ifstream ifs("/home/main/map/carto_ws0222/map/2d-1Task.json");
  if (!ifs.is_open())
  {
      std::cerr << "Failed to open json file"<<std::endl;
  }
  std::string line;
  while (std::getline(ifs, line))
  {
      nlohmann::json json_doc;
      try
      {
          json_doc = nlohmann::json::parse(line);
      }
      catch(const std::exception& e)
      {
          std::cerr <<"Failed to parse JSON data"<<e.what() << std::endl;
          continue;
      }
      std::string path_i = json_doc["name"];
      std::cout <<std::stoi(path_i)<<std::endl;
      if (std::stoi(path_i) == id)
      {
          auto array_data_x = json_doc["x"];
          auto array_data_y = json_doc["y"];

          if (array_data_x.size() == array_data_y.size())
          {
              std::cout<<"array_data 的长度 = "<<array_data_x.size()<<std::endl;
              for (size_t i = 0; i < array_data_x.size(); i++)
              {
                temp.push_back({(float)array_data_x[i]*1000, (float)array_data_y[i]*1000, 0, 0, 0, 1});
              }
              (temp.end()-1)->previous_task = 60;
              (temp.end()-1)->mode_type = 0; 
              temp.push_back({0,0,0,0,0,0});
          }
      } 
  }
}

// 从json文件中读取路径数据发送个plc
void read_path_tasks(int id, std::vector<pose_send_vector>& temp)
{
  std::ifstream ifs("/home/main/map/carto_ws0222/map/2d-1Task.json");
  if (!ifs.is_open())
  {
      std::cerr << "Failed to open json file"<<std::endl;
  }
  std::string line;
  while (std::getline(ifs, line))
  {
      nlohmann::json json_doc;
      try
      {
          json_doc = nlohmann::json::parse(line);
      }
      catch(const std::exception& e)
      {
          std::cerr <<"Failed to parse JSON data"<<e.what() << std::endl;
          continue;
      }
      std::string path_i = json_doc["name"];
      std::cout <<std::stoi(path_i)<<std::endl;
      if (std::stoi(path_i) == id)
      {
          auto array_data_x = json_doc["x"];
          auto array_data_y = json_doc["y"];
          auto array_previous_tasks = json_doc["previous_task"];
          auto array_mode_type = json_doc["mode_type"];

          if (array_data_x.size() == array_data_y.size())
          {
              std::cout<<"array_data 的长度 = "<<array_data_x.size()<<std::endl;
              for (size_t i = 0; i < array_data_x.size(); i++)
              {
                temp.push_back({(float)array_data_x[i]*1000, (float)array_data_y[i]*1000, 0, (int16_t)array_previous_tasks[i], 0, (int16_t)array_mode_type[i]});
              }
              // (temp.end()-1)->previous_task = 60;
              // (temp.end()-1)->mode_type = 0; 
              temp.push_back({0,0,0,0,0,0});
          }
      } 
  }
}

static void WriteExample(
  const AdsDevice& route,
  current_pose_node& w_current,
  std::vector<float> fblr_detection,
  const float &w_current_yaw,
  const float &w_pose_x,
  const float &w_pose_y
)
{   
    std::vector<pose_send_vector> temp;
    // topic send data
    temp = w_current.p_temp;
    if (temp.size() != 0)
    {
      global_path = w_current.p_temp;
    }
    w_current.p_temp.clear();
    // 接受调度系统的信号 传入 path_id里面
    AdsVariable<int> path_num {route, 0X4020, 0X22e};
    path_id = (int)path_num;
    if (path_id)
    {
      read_path_tasks(path_id, temp);
      if (temp.size() != 0)
      {
        global_path = temp;
      }
      path_id = 0;
      AdsVariable<int> path_num_clear {route, 0X4020, 0X22e};
      path_num_clear = 0;
    }
    // 检测定位是否丢失

    if (temp.size()>0)
    {
      std::array<uint8_t, 200> bites{};
      AdsVariable<std::array<uint8_t, 200>> arrayVar(route, 0X4020, 0X4664);

      size_t offset = 0;
      for (auto elem : temp)
      {
        std::memcpy(&bites[offset], &(elem.pose_x), sizeof(float));
        offset += sizeof(float);
        std::memcpy(&bites[offset], &(elem.pose_y), sizeof(float));
        offset += sizeof(float);
        std::memcpy(&bites[offset], &(elem.obstacle_avoidance_signal), sizeof(int16_t));
        offset += sizeof(int16_t);
        std::memcpy(&bites[offset], &(elem.previous_task), sizeof(int16_t));
        offset += sizeof(int16_t);
        std::memcpy(&bites[offset], &(elem.post_task), sizeof(int16_t));
        offset += sizeof(int16_t);
        std::memcpy(&bites[offset], &(elem.mode_type), sizeof(int16_t));
        offset += 3*sizeof(int16_t);
      }
      arrayVar = bites;

      delay_msec(100*1000);
      // 触发自动行驶信号
      AdsVariable<bool> arrayVar1 {route, 0X4020, 0X8};
      arrayVar1 = true;

      temp.clear();
    }
    if (temp.size() == 0)
    {

      if ((w_pose_x != 0) && (w_pose_y != 0))
      {
        // 心跳信号一直为1
        int AGV_Heartbeat_signal = 1;
        size_t offset = 0;
        std::array<uint8_t, 32> bites{};
        AdsVariable<std::array<uint8_t, 32>> arrayVar(route, 0X4020, 0X278);
        std::memcpy(&bites[offset], &AGV_Heartbeat_signal, sizeof(int16_t));
        offset += sizeof(int16_t);
        std::memcpy(&bites[offset], &w_current_yaw, sizeof(float));
        offset += sizeof(float);
        std::memcpy(&bites[offset], &w_pose_x, sizeof(float));
        offset += sizeof(float);
        std::memcpy(&bites[offset], &w_pose_y, sizeof(float));
        offset += sizeof(float);

        // float* ptr = &fblr_detection[0];
        float obsts_f,obsts_b,obsts_l,obsts_r;
        obsts_f = fblr_detection[0]*1000;
        obsts_b = fblr_detection[1]*1000;
        obsts_l = fblr_detection[2]*1000;
        obsts_r = fblr_detection[3]*1000;

        std::memcpy(&bites[offset], &obsts_f, sizeof(float));
        offset += sizeof(float);
        std::memcpy(&bites[offset], &obsts_b, sizeof(float));
        offset += sizeof(float);
        std::memcpy(&bites[offset], &obsts_l, sizeof(float));
        offset += sizeof(float);
        std::memcpy(&bites[offset], &obsts_r, sizeof(float));
        arrayVar = bites;
      }
    }
    w_current.p_temp.clear();
}

static void runExample(
  const AdsDevice& route,
  current_pose_node& r_current,
  std::vector<float> fblr_detection,
  const float &r_current_yaw, 
  const float &r_pose_x, 
  const float &r_pose_y
)
{

    WriteExample(route, r_current, fblr_detection, r_current_yaw, r_pose_x, r_pose_y);

}


int main(int argc, char *argv[])
{   
    // ADS通信参数
    static const AmsNetId remoteNetId { 169, 254, 27, 166, 1, 1 };
    static const char remoteIpV4[] = "169.254.27.166";
    AdsDevice route {remoteIpV4, remoteNetId, AMSPORT_R0_PLC_RTS1};
    // ros相关参数
    ros::init(argc, argv, "getRobotPose");
    tf2_ros::Buffer buffer(ros::Duration(10));
    tf2_ros::TransformListener listener(buffer);
    current_pose_node curPose("map", "base_link");
    std::vector<float> fblr_distance;
    geometry_msgs::PoseStamped global_pose;
    float current_yaw;
    float pose_x;
    float pose_y;
    std::vector<std::vector<float>> pose_x_y_yaw;
    isPublishPath = true;
    state_temp_ = site_1;
    path_id = 0;
  
    while (ros::ok())
    {   

        fblr_distance = curPose.scanObstacleDetectionToshortestDistanceAroundAGV();

        curPose.getRobotPose(global_pose, buffer);
        curPose.getXYposition(global_pose, pose_x, pose_y);  // pose_x pose_y  × 1000
        curPose.getCurrentYaw(global_pose, current_yaw);  // tfq × 1000

        // 偏离路径和定位乱跳 就停车
        if (isAwayFromPath(pose_x, pose_y, global_path) || isPositionLoss(pose_x, pose_y, current_yaw, pose_x_y_yaw))
        {
          AdsVariable<bool> arrayVar1 {route, 0X4020, 0Xb};
          arrayVar1 = true;
        }

        std::cout <<" obstacle: "<<fblr_distance.at(0)<<" "<< fblr_distance.at(1)<<" " << fblr_distance.at(2)<<" "<<fblr_distance.at(3)<<" current_yaw:"<<current_yaw<<"pose_x:"<<pose_x<<"pose_y:"<<pose_y<<std::endl;
        try {
          // 传递实时参数 (agv位置丢失停车信号, 避障信号(四个方向距离大小), 角度, x坐标值, y坐标值)
          runExample(route, curPose, fblr_distance, current_yaw, pose_x*1000, pose_y*1000);
          // continue;
        } 
        catch (const AdsException& ex) {
          std::cout << "Error: " << ex.errorCode << "\n";
          std::cout << "AdsException message: " << ex.what() << "\n";
          // continue;
        } 
        catch (const std::runtime_error& ex) {
          std::cout << ex.what() << '\n';
          // continue;
        }
        ros::spinOnce();
        delay_msec(50*1000);
        
        
    }   
    return 0;
}
